# CuanCat — Dokumentasi Codebase

Tamagotchi cat overlay untuk aplikasi iOS (OCBC Mobile). Kucing hidup di atas semua UI
sebagai floating overlay, bereaksi terhadap loading dan hasil transaksi, dan memberikan
voucher apologi saat stress terlalu tinggi.

---

## Struktur File

```
CuanCat/
├── Constants/
│   ├── CatAssetManifest.swift      — nama file .json (Lottie) per animasi + validasi
│   ├── CatVideoManifest.swift      — nama file .mov per animasi + validasi (pipeline legacy)
│   └── CatConstants.swift          — semua magic number: timing, layout, stress, persistence keys
│
├── Models/
│   ├── CatState.swift              — CatState enum, CatDirection, CatLoadingType, CatEvent, CatSideEffect
│   ├── CatAnimationType.swift      — 5 tipe animasi (idle/walk/annoyed/happy/exhausted)
│   ├── CatMood.swift               — MoodHistoryEntry (log state + stress snapshot)
│   ├── CatTransactionError.swift   — error types dari service eksternal
│   └── VoucherModel.swift          — VoucherModel + VoucherType
│
├── State/
│   ├── CatStateMachine.swift                       — pure state machine, compute transition + side effects
│   ├── CatStateMachine+IdleTransitions.swift       — idle ↔ walking transitions
│   ├── CatStateMachine+LoadingTransitions.swift    — loading → exhausted transitions
│   ├── CatStateMachine+TransactionTransitions.swift — success → happy / failed → annoyed
│   ├── CatBehaviorEngine.swift                     — central orchestrator, owns state machine + timers
│   ├── CatBehaviorEngine+SideEffects.swift         — eksekusi side effects (stress, voucher, haptic)
│   ├── CatBehaviorEngine+Timers.swift              — idle timer, loading timer, animation end scheduler
│   └── CatBehaviorEngine+Walk.swift                — walk cycle + animasi posisi linear
│
├── Overlay/
│   └── CatOverlayManager.swift     — singleton facade, PassThroughWindow, ShakeDetectingHostingController
│
├── Persistence/
│   └── CatPersistence.swift        — UserDefaults wrapper (stress, voucher history, mood history, dates)
│
├── Rendering/
│   ├── CatRenderable.swift         — protocol: makeBody(state:direction:) → View
│   ├── LottieCatRenderer.swift     — renderer utama via Lottie (.json) ← AKTIF
│   ├── USDCCatRenderer.swift       — renderer legacy via SceneKit (.usdc), tidak aktif
│   └── CatVideoRenderer.swift      — renderer legacy via AVFoundation (.mov), tidak aktif
│
└── Views/
    ├── CatContainerView.swift      — root SwiftUI layout (cat + passport + voucher overlay)
    ├── CatAvatarView.swift         — renders kucing + voucher badge
    ├── CatPassportView.swift       — stress gauge + voucher history sheet
    ├── VoucherEnvelopeView.swift   — envelope badge (bounce) + VoucherClaimOverlay + confetti
    └── CatDemoView.swift           — panel demo untuk office demo / QA
```

---

## Cat States (5 State)

| State | Trigger | Animasi | Looping | Auto-return ke idle |
|---|---|---|---|---|
| `idle` | Default, setelah walking/annoyed/happy | `cat_idle.json` | Ya | Tidak |
| `walking` | Idle >= 8 detik | `cat_walk.json` | Ya | Ya, setelah 45s atau sampai edge |
| `annoyed` | Transaksi gagal / error | `cat_annoyed.json` | Ya | Ya, setelah 3 detik |
| `happy` | Transaksi berhasil | `cat_happy.json` | Ya | Ya, setelah 3 detik |
| `exhausted` | Loading >= 10 detik (hanya mode `tracked`) | `cat_exhausted.json` | Ya | Tidak, tunggu `loadingStopped` |

**`isTransientReaction`** = true untuk `annoyed` dan `happy` — keduanya otomatis kembali ke `idle` via `animationFinished` event.

### Walking Direction
- `CatDirection.right` → `scaleX = 1.0` (normal)
- `CatDirection.left` → `scaleX = -1.0` (flip horizontal)
- Walk target = edge terjauh dari posisi saat ini

---

## Lottie Assets (Aktif)

Lima file `.json` diperlukan, masing-masing satu animasi loop:

| Asset Name | File | State | Keterangan |
|---|---|---|---|
| `cat_idle` | `cat_idle.json` | `.idle` | Default breathing/standing loop |
| `cat_walk` | `cat_walk.json` | `.walking` | Walking loop, flip X untuk kiri |
| `cat_annoyed` | `cat_annoyed.json` | `.annoyed` | Gagal transaksi loop |
| `cat_happy` | `cat_happy.json` | `.happy` | Berhasil transaksi loop |
| `cat_exhausted` | `cat_exhausted.json` | `.exhausted` | Loading > 10s loop |

**Cara taruh aset:**
- Drag `.json` ke folder di Xcode project → centang target app → Build Phases → Copy Bundle Resources
- `Animation.named("cat_idle")` (Lottie) otomatis mencari di main bundle
- Jalankan `CatAssetManifest.validateAssets()` untuk debug file yang hilang

### Renderer Active: `LottieCatRenderer`

Di `CatAvatarView.swift`:
```swift
private let renderer = LottieCatRenderer()   // ← aktif
// private let renderer = USDCCatRenderer()  // legacy SceneKit
// private let renderer = CatVideoRenderer() // legacy AVFoundation
```

`LottieCatRenderer` menggunakan `LottieView: UIViewRepresentable` yang wraps Lottie `AnimationView`.
Walk direction dihandle via `.scaleEffect(x: direction.scaleX)` — flip horizontal tanpa file terpisah.

### Renderer Legacy (tidak aktif)
- `USDCCatRenderer` — SceneKit + `.usdc` 3D assets, butuh `ActiveSceneViewHolder` untuk hit testing
- `CatVideoRenderer` — AVFoundation + `.mov`, butuh file `cat_*_movie.mov`

---

## Stress Level System

### Range & Tier

| Range | Label | Warna |
|---|---|---|
| 0–30 | Sehat | Hijau |
| 31–60 | Waspada | Kuning |
| 61–74 | Kritis | Oranye |
| 75–89 | Voucher (504) | Oranye gelap |
| 90–100 | Voucher! | Merah |

### Stress Modifiers

| Event | Delta | Catatan |
|---|---|---|
| Transaksi berhasil | -15 | `transactionSuccessReduction` |
| Transaksi gagal | +10 | `transactionFailedIncrease` |
| HTTP 504 Gateway Timeout | +20 | `gatewayTimeoutIncrease` |
| HTTP 5xx Server Error | +15 | `serverErrorIncrease` |
| Network Error | +10 | `networkErrorIncrease` |
| HTTP 4xx Client Error | 0 | Hanya trigger annoyed animation, no stress |
| Ganti hari | -20 | `dailyDecay`, tidak reset ke 0 |
| Setelah klaim voucher | → 30 | Reset ke 30 (bukan 0 — hindari farming) |

### Patience System (per loading request)

Setiap request dimulai dengan `patience = 100`, decay per detik:

| Elapsed | Decay/tick |
|---|---|
| 0–3 detik | -2 (masih in flow) |
| 3–6 detik | -5 (mulai sadar menunggu) |
| 6–10 detik | -9 (tidak sabar) |
| > 10 detik | -15 (exhausted zone) |

Konversi patience → stress delta saat loading selesai:

| Patience | Stress Delta |
|---|---|
| 80–100 | -5 (fast, user puas) |
| 60–79 | 0 (normal) |
| 40–59 | +8 (mulai frustrasi) |
| 20–39 | +18 (frustrasi) |
| 1–19 | +30 (sangat frustrasi) |
| 0 | +50 (patience habis) |

---

## Voucher Logic

### Trigger Conditions (OR)

1. **Stress >= 90** (`voucherStressThreshold`) → voucher normal
2. **Stress >= 75** (`gatewayTimeoutVoucherThreshold`) → khusus setelah HTTP 504
3. **Exhausted >= 3x dalam 1 sesi** (`exhaustedSessionVoucherCount = 3`)

### Cooldown
- 1x per 24 jam (`voucherCooldownInterval = 86400s`)
- Dicek via `VoucherModel.canGenerateVoucher(lastGeneratedDate:)`

### Flow
```
checkAndShowVoucher() / checkAndShowVoucherEarly()
  → tryShowVoucher()
  → setShowVoucherEnvelope(true)
  → user tap envelope → handleVoucherTapped()
  → isVoucherOverlayVisible = true, pendingVoucher dibuat
  → user tap "Klaim Voucher" → handleVoucherClaim()
  → voucherHistory.append, stressPoints = 30, cooldown dicatat
```

### VoucherType
- `apology` — kucing exhausted / stress tinggi ("Sorry for the wait!")
- `loyalty` — future: repeated usage reward
- `milestone` — future: interaction milestones

### Voucher Code Format
`CAT-XXXXXX` (6 karakter random dari A-Z + 0-9), expiry 7 hari.

---

## Loading Mode: tracked vs silent

| Mode | Exhausted Animation | Stress |
|---|---|---|
| `.silent` (default) | Tidak | Ya (patience system) |
| `.tracked` | Ya, jika > 10 detik | Ya (patience system) |

**Cara opt-in tracked dari viewmodel:**
```swift
CatOverlayManager.shared.trackNextLoading()  // sebelum operasi
baseService.submitOrder()                     // startLoading() otomatis jadi tracked
```
Base service tidak perlu diubah — flag dikonsumsi satu kali lalu reset.

---

## Overlay & Window Architecture

- `PassThroughWindow` — `UIWindow` custom yang hanya intercept touch di area kucing (rect check). Touch di luar area diteruskan ke window aplikasi utama. Dengan Lottie 2D, rect check sudah cukup (tidak perlu geometry hit test seperti USDC).
- `ShakeDetectingHostingController` — `UIHostingController` yang override `motionEnded` untuk detect shake → `bringBack()`.
- Window level: `10_000_000` (di atas semua UI normal).

---

## Public API (CatOverlayManager.shared)

```swift
// Lifecycle
show()
hide()

// Loading
trackNextLoading()          // opt-in exhausted untuk 1x loading berikutnya
startLoading()              // default: .silent (hanya patience+stress, tidak ada exhausted)
stopLoading()               // no-op jika startLoading() belum pernah dipanggil (guard isLoadingActive)

// Transaksi
transactionSuccess()        // → happy animation, stress -15
transactionFailed()         // → annoyed animation, stress +10
reportError(_ type: CatTransactionError)  // stress sesuai tipe

// Walking control
setWalkingEnabled(true)     // dashboard: boleh jalan
setWalkingEnabled(false)    // halaman transaksi: diam

// Dismiss / bring back
dismiss()
bringBack()                 // masuk dari luar layar dengan walk animation
showPassport()              // buka stress gauge sheet

// Demo (office/QA)
showDemo(from:)
```

```swift
// CatBehaviorEngine (internal, tapi diakses via CatDemoView)
engine.cancelPendingAnimations()  // cancel animationTimerCancellable dengan aman
```

---

## Persistence (UserDefaults)

| Key | Tipe | Data |
|---|---|---|
| `cat_stress_points` | `Int` | stress saat ini |
| `cat_voucher_history` | `Data` (JSON) | `[VoucherModel]` |
| `cat_mood_history` | `Data` (JSON) | `[MoodHistoryEntry]`, max 50 entries |
| `cat_last_session_date` | `Date` | untuk daily decay check |
| `cat_last_voucher_date` | `Date` | untuk 24h cooldown |

Daily decay diterapkan saat launch jika `lastSessionDate` bukan hari ini.

---

## Timing Constants

| Konstanta | Value | Alasan |
|---|---|---|
| `idleToWalkThreshold` | 8 detik | 2 detik sebelum batas attention span Nielsen (10s) |
| `walkToIdleThreshold` | 45 detik | Satu patrol cycle selesai |
| `loadingExhaustedThreshold` | 10 detik | Nielsen max attention span |
| `annoyedDuration` | 3 detik | Auto-return ke idle |
| `happyDuration` | 3 detik | Auto-return ke idle |
| `walkCycleDuration` | 6 detik | Edge-to-edge full screen |

---

## Layout Constants

| Konstanta | Value |
|---|---|
| `avatarSize` | 240 pt |
| `bottomPadding` | 120 pt |
| `defaultStartXRatio` | 0.85 (kanan layar) |
| `overlayWindowLevel` | 10_000_000 |
| `walkingEdgePadding` | 20 pt |
| `walkHitSize` | 128 pt |

---

## Dependencies

| Framework / Library | Versi | Digunakan untuk |
|---|---|---|
| `Lottie` (airbnb/lottie-ios) | 3.2.3 | via CocoaPods — Render `.json` animation (renderer utama) |
| `SwiftUI` | system | Semua Views |
| `UIKit` | system | Overlay window, haptic, AVPlayerLayer |
| `AVFoundation` | system | Legacy CatVideoRenderer (.mov) |
| `SceneKit` | system | Legacy USDCCatRenderer (.usdc) |
| `Combine` | system | Timer, Published state di CatBehaviorEngine |
| `CoreGraphics` | system | CGFloat, CGRect di layout/walk calculations |
| `Foundation` | system | UUID, Date, JSONEncoder/Decoder, UserDefaults |

**Minimum iOS: 13** (semua API di-guard iOS 13 compatible, tidak ada `@available` guard yang melanggar ini).

---

## State Machine Flow

```
idle
  │ idleTimerTick >= 8s
  ▼
walking ──── idleTimerTick >= 45s / sampai edge ──→ idle
  │
  │ (loadingStarted → exhausted enabled)
  ▼
[any state] ── loadingStarted ──→ timer mulai (state tidak berubah)
                  │
                  │ tick >= 10s && .tracked
                  ▼
              exhausted
                  │
                  │ loadingStopped
                  ▼
                idle
                  
[any state] ── transactionSuccess ──→ happy ── animationFinished (3s) ──→ idle
[any state] ── transactionFailed  ──→ annoyed ── animationFinished (3s) ──→ idle
[any state] ── dayChanged ──→ applyStressDelta(-20), resetExhaustedCount
[any state] ── voucherClaimed ──→ idle (+ setHomeBase + resetIdleTimer + startIdleTimer)
```

---

## Demo Panel (CatDemoView)

Akses via `CatOverlayManager.shared.showDemo()`. Berisi:
- **Force Animation** — force state langsung (bypass state machine)
- **Stress Control** — slider 0–100, shortcut ke threshold penting
- **Cat Control** — toggle walking, dismiss/bring back, reset posisi
- **Voucher** — force show envelope, open overlay

Section yang di-comment out (hidden): Status, Transaction, Loading, Danger Zone.

---

## Catatan Penting — Default & Invariant

### Loading State Defaults
- `CatBehaviorEngine.currentLoadingType` default = `.silent` — exhausted tidak aktif kecuali `trackNextLoading()` dipanggil terlebih dahulu.
- `CatStateMachine.isExhaustedEnabled` default = `false` — harus di-set `true` secara eksplisit via `trackNextLoading()`, bukan default aktif.
- `isLoadingActive: Bool` di `CatBehaviorEngine` — guard agar `stopLoading()` tidak apply stress delta jika tidak ada loading aktif.

### Walk Animation
- Walk snap (interrupt ke state lain saat walking) memakai `withTransaction` + `transaction.disablesAnimations = true` — bukan `withAnimation(nil)`. Ini penting karena `withAnimation(nil)` tidak bisa cancel ongoing `withAnimation(.linear)` di SwiftUI.

### Dismiss / BringBack Invariant
- `dismiss()` harus cancel `animationTimerCancellable` via `cancelPendingAnimations()`. Tanpa ini, jika cat di-dismiss saat dalam state transient (happy/annoyed/sad), timer 3 detik tetap berjalan dan akan fire saat `bringBack()` sedang walk — menyebabkan state machine (masih di state lama) mem-proses `.animationFinished` dan menginterrupt walk.
- `bringBack()` harus sync `stateMachine.currentState` via `stateMachine.applyTransition(CatTransitionResult(newState: .walking, sideEffects: []))`. `setCurrentState(.walking)` hanya update `engine.currentState`, bukan `stateMachine.currentState` — divergence ini menyebabkan `processEvent` memproses event berdasarkan state yang salah selama walk.

### Idle Timer
- `startIdleTimer()` hanya memanggil `processEvent(.idleTimerTick)` sekali per tick (setelah cek `isWalkingEnabled`). Jangan duplikat call sebelum dan sesudah cek — menyebabkan double processing yang tidak perlu.

### VoucherOverlay Source of Truth
- `VoucherOverlayWrapper` memakai `engine.pendingVoucher` sebagai source of truth. Jangan gunakan `VoucherModel(voucherType:)` inline — setiap call ke init itu buat UUID dan kode baru yang menyebabkan render ulang tidak konsisten.

### CocoaPods Setup
Proyek ini memakai CocoaPods. Setelah clone:
```bash
pod install
# Buka testing.xcworkspace, bukan testing.xcodeproj
```
